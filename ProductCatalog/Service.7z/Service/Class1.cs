﻿using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Data;
using Dapper;
using Microsoft.Data.SqlClient;

namespace Service
{
    public class Class1
    {

        /*public async Task<List<ProductData>> GetDataFromStoredProcedure(string connectionString, string regionId, string storeId, string userId, string deptId, string prodId, string product, string tradingWeek, string tradingYear, string deptCode, string deptName, string sku, string prodName, string prodCode, string sPrice)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var parameters = new DynamicParameters();
                parameters.Add("@regionid", regionId);
                parameters.Add("@storeid", storeId);
                parameters.Add("@userid", userId);
                parameters.Add("@deptid", deptId);
                parameters.Add("@prodid", prodId);
                parameters.Add("@product", product);
                parameters.Add("@tradingweek", tradingWeek);
                parameters.Add("@tradingyear", tradingYear);
                parameters.Add("@DeptCode", deptCode);
                parameters.Add("@DeptName", deptName);
                parameters.Add("@SKU", sku);
                parameters.Add("@ProdName", prodName);
                parameters.Add("@ProdCode", prodCode);
                parameters.Add("@SPrice", sPrice);

                var result = await connection.QueryAsync<ProductData>("ICA_Query_CatWan_Search", parameters, commandType: CommandType.StoredProcedure);

                return result.ToList();
            }
        }*/

        public async Task<List<ProductData>> GetDataFromStoredProcedure(string connectionString, CatalogueData data)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var parameters = new DynamicParameters();
                parameters.Add("@regionid", 60);
                parameters.Add("@storeid", null);
                parameters.Add("@userid", "ww166");
                parameters.Add("@deptid", data.DeptId); //6201
                parameters.Add("@prodid", null);
                parameters.Add("@product", null);
                parameters.Add("@tradingweek", 9);
                parameters.Add("@tradingyear", 2015);
                parameters.Add("@DeptCode", null);
                parameters.Add("@DeptName", null);
                parameters.Add("@SKU", null);
                parameters.Add("@ProdName", null);
                parameters.Add("@ProdCode", null);
                parameters.Add("@SPrice", null);

                /* parameters.Add("@regionid", 60);
                 parameters.Add("@storeid", data.StoreId);
                 parameters.Add("@userid", "ww166");
                 parameters.Add("@deptid", data.DeptId);
                 parameters.Add("@prodid", data.ProdId);
                 parameters.Add("@product", data.Product);
                 parameters.Add("@tradingweek", data.TradingWeek);
                 parameters.Add("@tradingyear", data.TradingYear);
                 parameters.Add("@DeptCode", data.DeptCode);
                 parameters.Add("@DeptName", data.DeptName);
                 parameters.Add("@SKU", data.SKU);
                 parameters.Add("@ProdName", data.ProdName);
                 parameters.Add("@ProdCode", data.ProdCode);
                 parameters.Add("@SPrice", data.SPrice);*/

                var result = await connection.QueryAsync<ProductData>("ICA_Query_CatWan_Search_test_ash", parameters, commandType: CommandType.StoredProcedure);

                //return result.Take(100).Where(x => x.TradingYear == "2011").ToList();

                 return result.Take(100)
                .Where(x => x.TradingYear == "2011")
                .GroupBy(x => x.ProdCode) // Group items by ProductCode
                .Select(group => group.First()) // Select the first item from each group
                .ToList();
            }
        }

        public async Task<List<Store>> GetStores(string connectionString)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var parameters = new DynamicParameters();
                parameters.Add("@StoreID", null);
                parameters.Add("@StoreName", null);

                var result = await connection.QueryAsync<Store>("ICA_Query_CatWan_Stores", parameters, commandType: CommandType.StoredProcedure);

                return result.ToList();
            }
        }

        public async Task<List<Dept>> GetDepartments(string connectionString, int storeId)
        {
            using (var connection = new SqlConnection(connectionString))
            {
               
                var sql = $"SELECT DISTINCT CS.dept_id as department_id, CS.dept_nme as department_name from CS_Caissa_Central_Master_Data.dbo.DEPARTMENT CS where cs.dept_id in (SELECT [DeptCode] FROM[CS_Third_Party_Foods_Catalogue].[dbo].[StoreDept] where storeid = {storeId})";

                var result = await connection.QueryAsync<Dept>(sql, commandType: CommandType.Text);

                return result.ToList();
            }
        }

        public async Task<List<Dept>> GetDepartmentsById(string connectionString, int departmentId)
        {
            using (var connection = new SqlConnection(connectionString))
            {

                //var sql = $"SELECT DISTINCT CS.dept_id as department_id, CS.dept_nme as department_name from CS_Caissa_Central_Master_Data.dbo.DEPARTMENT CS where dept_id = {departmentId}";

                var sql = $"select CS.dept_id as department_id, CS.dept_nme as department_name, CS.group_id from CS_Caissa_Central_Master_Data.dbo.DEPARTMENT CS where dept_id = {departmentId}";

                var result = await connection.QueryAsync<Dept>(sql, commandType: CommandType.Text);

                return result.ToList();
            }
        }



        public async Task<List<ProductGroup>> GetProductGroups(string connectionString, int groupId)
        {
            using (var connection = new SqlConnection(connectionString))
            {

                var sql = $"SELECT [group_id] ,[group_nme] ,[division_id] ,[active_ind] ,[action_ind] ,[extract_seq_no] FROM [CS_Caissa_Central_Master_Data].[dbo].[GROUP] where group_id = {groupId}";

                var result = await connection.QueryAsync<ProductGroup>(sql, commandType: CommandType.Text);

                return result.ToList();
            }
        }



    }

    public class ProductData
    {
        public string DeptCode { get; set; }
        public string DeptName { get; set; }
        public string SKU { get; set; }
        public string ProdName { get; set; }
        public string ProdCode { get; set; }
        public string SPrice { get; set; }
        public string TradingYear { get; set; }
        public string TradingWeek { get; set; }
        public string PeriodStart { get; set; }
        public string PeriodEnd { get; set; }
        public string PeriodInd { get; set; }
    }

    public class CatalogueData
    {
        public string RegionId { get; set; }
        public string StoreId { get; set; }
        public string UserId { get; set; }
        public string DeptId { get; set; }
        public string ProdId { get; set; }
        public string Product { get; set; }
        public string TradingWeek { get; set; }
        public string TradingYear { get; set; }
        public string DeptCode { get; set; }
        public string DeptName { get; set; }
        public string SKU { get; set; }
        public string ProdName { get; set; }
        public string ProdCode { get; set; }
        public string SPrice { get; set; }
    }

    public class Store
    {
        public string Store_Id { get; set;}
        public string Store_Name { get; set;}
    }

    public class Dept
    {
        public string Department_id { get; set; }
        public string Department_name { get; set; }

        public string Group_id { get; set; }
    }

    public class ProductGroup
    {
        public string Group_id { get; set; }
        public string Group_Nme { get; set; }
    }
}